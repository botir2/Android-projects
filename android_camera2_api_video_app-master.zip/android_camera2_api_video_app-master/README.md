# android_camera2_api_video_app
[![Contact me on Codementor](https://cdn.codementor.io/badges/contact_me_github.svg)](https://www.codementor.io/mobapptuts?utm_source=github&utm_medium=button&utm_term=mobapptuts&utm_campaign=github)

Android tutorial code that describes how to create an android video application using the android camera2 API.

Code for the android tutorial series found here https://www.youtube.com/playlist?list=PL9jCwTXYWjDIHNEGtsRdCTk79I9-95TbJ that describes how to create an android video application using the android camera2 API.
