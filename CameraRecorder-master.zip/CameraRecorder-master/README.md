# CameraRecorder
This is a sample project to show how to record video by camera in the background service.
The sample need be built in API Level 16 (or later).

Notice!
This sample is only tested on HTC One (M8) device (Android 5.0.2).
