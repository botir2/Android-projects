package com.wonderkiln.camerakit;

import android.annotation.TargetApi;

@TargetApi(21)
class Camera2 {
}
